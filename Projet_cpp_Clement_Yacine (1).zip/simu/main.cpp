#include <vector>
#include <fstream>
#include "graphe.hpp"
#include "iostream"
#include <map>
#include <string>

using namespace std;

/**
*   Cette fonction permet d'afficher la table d'ID_node
*   d'un objet de type graphe.
*   @param g : l'objet contenant la table d'ID_node.
**/
void printTabIDs_Gates( graph g);

/**
*   Cette fonction permet d'afficher la matrice d'adjacence
*   d'un objet de type graphe.
*   @param g : l'objet contenant la matrice d'adjacence.
**/
void printAdjMatrix(graph g);

void printTabIDs_Gates(graph g){

    vector<string> k = g.getID_node();

    cout << "Tab ID nodes: " << endl;
    for (int i = 0; i < k.size(); i++){
            cout << k[i] <<  endl;
    }

    cout << "\nTab Gates: " << endl;
    vector<PorteGenerique*> p = g.getList_gates();

    for (int i = 0; i < p.size(); i++){
            cout << "Gate" << i + 1 << endl;
            (*p[i]).Calculate_output();
            (*p[i]).print_info();
    }
    cout << endl;
}

void printAdjMatrix(graph g){
    cout << "Adjacent Matrix" << endl;
    vector<vector<int>> Matrix = g.getAdjMatrix();
    vector<string> ID = g.getID_node();
    cout <<  "    ";
    for (int i = 0 ; i < ID.size(); i++){
            cout << ID[i] << " ";
    }
    cout << "\n";

    for( int i = 0; i < Matrix.size(); i++){
        int taille_j = Matrix[i].size();
        cout << ID[i] << " |";
        for( int j = 0; j < taille_j; j++){
            cout << Matrix[i][j] << " |";
        }
        cout << "\n";
    }
    cout << endl;
}


int main()
{
    // Cette partie sert � tester les diff�rents circuits
    string filename = "circuit_2.txt";
    /*graph g;
    g.tabIDs(filename);
    g.AdjacencyMatrix(filename);
    */
    graph g(filename);

    printTabIDs_Gates(g);
    printAdjMatrix(g);

    g.solve("vectors_l.txt");

    printTabIDs_Gates(g);

/* cette partie servait � tester si les classes fonctionnaient
    correctement.
*/
/*
    AND porte1(2);
    OR porte2(2);
    vector<int> input = {1, 1};
    porte1.Set_input(input);
    porte1.Calculate_output();
    porte1.print_info();


    cout << "adresses portes: " << endl; cout << &porte1 << endl; cout << &porte2 << endl;
    vector<PorteGenerique*> gen_gate;
    gen_gate.push_back(&porte1);
    gen_gate.push_back(&porte2);

    cout << "\nadresses tab:" << endl;
    PorteGenerique* tmp = gen_gate[0];
    cout << tmp << endl;
    (*tmp).print_info();

    PorteGenerique* tmp1 = gen_gate[1];
    vector<int> input2 = {1, 0};
    (*tmp1).Set_input(input2);
    (*tmp1).Calculate_output();
    (*tmp1).print_info();
    */

    return 0;
}

