#include "iostream"
#include <vector>
#include "simulateur.hpp"

using namespace std;

PorteGenerique::PorteGenerique(){}

PorteGenerique::PorteGenerique(int N)
{
    for (int i=0; i<N; i++) input.push_back(0);
}

AND::AND(int N)
{
    for (int i=0; i<N; i++) input.push_back(0);
}

NAND::NAND(int N)
{
    for (int i=0; i<N; i++) input.push_back(0);
}

OR::OR(int N)
{
   for (int i=0; i<N; i++) input.push_back(0);
}

NOR::NOR(int N)
{
    for (int i=0; i<N; i++) input.push_back(0);
}

XOR::XOR(int N)
{
    for (int i=0; i<N; i++) input.push_back(0);
}

NOT::NOT(int N)
{
    for (int i=0; i<N; i++) input.push_back(0);
}

void PorteGenerique::print_info()
{
    //On affiche toutes les entr�es de la porte.
    for(int i=0;i<(input.size());i++)
    {
        cout << "La valeur d'entree " << i << " est : " << input[i] << endl;
    }
    //On affiche la sortie.
    cout << "La valeur de la sortie est : " << output << endl;
}

void AND::print_info()
{
    //On affiche la type de la porte.
    cout<< "porte AND" << endl;
    //On affiche les autres informations de la porte.
    PorteGenerique::print_info();
}

void NAND::print_info()
{
    //On affiche la type de la porte.
    cout<< "porte NAND" << endl;
    //On affiche les autres informations de la porte.
    PorteGenerique::print_info();
}

void OR::print_info()
{
    //On affiche la type de la porte.
    cout<< "porte OR" << endl;
    //On affiche les autres informations de la porte.
    PorteGenerique::print_info();
}

void NOR::print_info()
{
    //On affiche la type de la porte.
    cout<< "porte NOR" << endl;
    //On affiche les autres informations de la porte.
    PorteGenerique::print_info();
}

void XOR::print_info()
{
    //On affiche la type de la porte.
    cout<< "porte XOR" << endl;
    //On affiche les autres informations de la porte.
    PorteGenerique::print_info();
}

void NOT::print_info()
{
    //On affiche la type de la porte.
    cout<< "porte NOT" << endl;
    //On affiche les autres informations de la porte.
    PorteGenerique::print_info();
}

void PorteGenerique::Set_input(vector<int> v)
{
    for(int i=0; i<v.size();i++) input[i]=v[i];
}

void PorteGenerique::Set_input(int index, int val){
    input[index] = val;
}

int AND::Calculate_output()
{
    int res=1;      //valeur non prioritaire
    for(int i=0; i<(input.size());i++)
    {
        res = res && input[i];
    }

    output = res;   //Mise � jour de la sortie
    return output;
}

int NAND::Calculate_output()
{
    int res=1;      //Valeur non prioritaire.
    for(int i=0; i<(input.size());i++)
    {
        res = res && input[i];
    }
    output = !res;   //Mise � jour de la sortie.
    return output;
}

int OR::Calculate_output()
{
    int res=0;      //Valeur non prioritaire.
    for(int i=0; i<(input.size());i++)
    {
        res = res || input[i];
    }
    output = res;   //Mise � jour de la sortie.
    return output;
}

int NOR::Calculate_output()
{
    int res=0;      //valeur non prioritaire.
    for(int i=0; i<(input.size());i++)
    {
            res = res || input[i];
    }
    output = !res;  //Mise � jour de la sortie.
    return output;
}

int NOT::Calculate_output()
{
    //On inverse la premi�re entr�e car cette porte ne contient qu'une entr�e.
    //On consid�re donc la premi�re entr�e comme seule entr�e actif.
    output=!input[0];   //Mise � jour de la sortie.
    return output;
}

int XOR::Calculate_output()
{
    int cpt=0;
    for(int i=0; i<(input.size());i++)
    {
            cpt = cpt + input[i]; //Comptes le nombre de 1 dans le vecteur d'entr�es.
    }
    output = cpt % 2; ////Mise � jour de la sortie en faisant la parit�.
    return output;
}

int PorteGenerique::Calculate_output(){ return -1;}

PorteGenerique::~PorteGenerique(){};
AND::~AND() {};
NAND::~NAND() {};
OR::~OR() {};
NOR::~NOR() {};
XOR::~XOR() {};
NOT::~NOT() {};


