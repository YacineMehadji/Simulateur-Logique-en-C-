Projet C++ réalisé par GUSTAVE Clément et MEHADJI Yacine.

L'objectif de ce projet était de réaliser un compilateur permettant de réaliser la decription d'un circuit à partir d'un fichier .txt.
Puis de calculer les valeurs en sortie du circuits en fonction des valeurs d'entrées qui sont lues à partir d'un fichier .txt.

Nous avons réalisé ce projet sur l'environnement de développment CODEBLOCKS.

Le projet contient 2 fichiers .hpp et .cpp, en plus du main.cpp, qui sont :
-simulateur
-graphe