#ifndef graph_HEADER
#define graph_HEADER
#include "iostream"
#include <fstream>
#include "simulateur.hpp"
#include <vector>

using namespace std;

/**
*   La classe repr�sentera la description du circuit sous forme
*   de graphique, un graphe d'arbre. Ce graphique sera repr�sentable
*   � l'aide d'attributs qui permettront d'effectuer la connection
*   entre les noeuds.
**/
class graph
{
private:
    vector<string> ID_node;         //Attribut qui contiendra tout les noeuds de l'arbre
    vector<PorteGenerique*> list_gates;     //Attribut dont les �l�ments pointeront sur les objets(portes)
    vector<vector<int>> adjMatrix;      //Matrice permettant de voir la connection entre chaque noeuds
    int index_inp;                  //Indice de la premi�re entr�e primaire dans le vecteur ID_node
    int index_outp;                 //Indice de la premi�re sortie primaire dans le vecteur ID_node

    /**
    *   M�thode permettant de retrouver l'indice de la premi�re
    *   occurence de l'�l�ment recherch� dans une zone donn�e dans
    *   le vecteur.
    *   @param vec : vecteur que l'on parcoure.
    *   @param e : l'�lement recherch�.
    *   @param start: l'indice de d�part pour la recherche.
    *   @param stop : l'indice d'arr�t de la recherche.
    *   @return l'indice si l'�l�ment est trouv� sinon -1.
    **/
    template <typename T>
    int findIndex(vector<T> vec, T e, int start, int stop);

    /**
    *   M�thode permettant de parcourir tout les chemins
    *   d'un arbre � partir d'un noeud. Si le noeud est
    *   une porte alors la sortie de la porte est mise � jour.
    *   @param noeud : noeud actuel o� l'on se trouve.
    *   @param val_prec : valeur pr�c�dente calcul� au noeud pr�c�dent.
    *   @param noeud_prec : le noeud pr�c�dent.
    **/
    void DFS(int noeud, int val_prec, int noeud_prec);


public:
    graph ();
    ~graph ();
    graph(string desc_cir);
    /**
    *   M�thode permettant de r�aliser la table ID_node
    *   en fonction de la description du fichier.
    *   @param desc_cir : nom du fichier contenant la description.
    **/
    void tabIDs(string desc_cir);

    /**
    *   M�thode permettant de r�aliser la matrice d'adjacence
    *   en fonction de la description du fichier et de la table
    *   ID_node.
    *   @param desc_cir : nom du fichier contenant la description.
    **/
    void AdjacencyMatrix(string desc_cir);

    /**
    *   @return la table d'ID_node.
    **/
    vector<string> getID_node();

    /**
    *   @return la liste des objets.
    **/
    vector<PorteGenerique*> getList_gates();

    /**
    *   @return la matrice d'adjacence.
    **/
    vector<vector<int>> getAdjMatrix();

    /**
    *   M�thode permettant de calculer les sorties
    *   primaires en fonction des valeurs pass�es dans
    *   les entr�es primaire. On affiche les r�sultats.
    *   @param file_vec : nom du fichier contenant les entr�es primaires.
    **/
    void solve(string file_vec);


};
#endif // graph_HEADER







