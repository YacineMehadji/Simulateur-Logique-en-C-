#ifndef PorteGenerique_HEADER
#define PorteGenerique_HEADER
#include "iostream"
#include <vector>


using namespace std;

/**
*   La classe m�re regroupant les diff�rentes portes logiques.
**/
class PorteGenerique
{
protected:
    vector<int> input;  //Les entr�es de la porte.
    int output;         //La sortie de la porte.

public:
    PorteGenerique();
    PorteGenerique(int N);
    ~PorteGenerique();

    /**
    *   La m�thode affiche les diff�rentes informations des
    *   de la porte g�n�rique.
    **/
    virtual void print_info();

    /**
    *  La m�thode mets � jour les entr�es de la porte.
    *  @param vec_inputs : vecteur d'entr�es.
    **/
    void Set_input(vector<int> vec_inputs);

    /**
    *  La m�thode met � jour une entr�e de la porte.
    *  @param index : l'entr�e � mettre � jour.
    *  @param val : valeur � ins�rer dans l'entr�e.
    **/
    void Set_input(int index, int val);

    /**
    *  La m�thode calcule et met � jour la sortie de la porte.
    *  @return int : la valeur de la sortie.
    **/
    virtual int Calculate_output();
};


/*  Les prochaines classes sont les classes filles de PorteGenerique.
    Elles poss�dent tous la m�me structure et par cons�quent les m�mes
    m�thodes. On ne d�finira pas ces m�thodes car elles sont les m�mes que
    celles de la classe m�re.
*/


class AND : public PorteGenerique
{
public:
    AND (int N);
    ~AND();
    void print_info();
    int Calculate_output();

};


class NAND : public PorteGenerique
{
public:
    NAND (int N);
    ~NAND();
    void print_info();
    int Calculate_output();

};


class OR : public PorteGenerique
{
public:
    OR(int N);
    ~OR();
    void print_info();
    int Calculate_output();
};


class NOR : public PorteGenerique
{
public:
    NOR(int N);
    ~NOR();
    void print_info();
    int Calculate_output();
};


class NOT : public PorteGenerique
{
public:
    NOT(int N);
    ~NOT();
    void print_info();
    int Calculate_output();
};


class XOR : public PorteGenerique
{
public:
    XOR(int N);
    ~XOR();
    void print_info();
    int Calculate_output();
};


#endif // PorteGenerique
