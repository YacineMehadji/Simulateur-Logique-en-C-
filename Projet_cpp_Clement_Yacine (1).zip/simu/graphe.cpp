#include "iostream"
#include "graphe.hpp"
#include <vector>
#include "simulateur.hpp"
#include <fstream>
#include <map>
#include <string>

using namespace std;

graph::graph(){}

graph::graph(string desc_circuit){
    tabIDs(desc_circuit);
    AdjacencyMatrix(desc_circuit);
}


template <typename T>
int graph::findIndex(vector<T> vec, T e, int start, int stop){

    if(start < vec.size() && stop < vec.size() && start < stop){
        for(int i = start; i < stop; i++){
            if(e  == vec[i]){
                return i;
            }
        }
    }
    return -1;
}


void graph::tabIDs(string desc_cir){

    ifstream infile(desc_cir);
    string buffer;                      //Variable qui contiendra un mot du fichier
    vector<string> inputs_outputs;      //Variable qui contiendra les entr�es et sorties primaires
    vector<string> type_g;              //Variable qui repr�sentera le type de la porte

    //Lorsque le caract�re ';' est atteint alors c'est la fin de la ligne et
    //on passe � la ligne suivante
    while(!infile.eof()){
        infile >> buffer;   //Premier mot d'une ligne

        //Les deux premi�res lignes du fichiers sont les entr�es et sorties primaires
        if((buffer.compare("INPUT") == 0 ) || (buffer.compare("OUTPUT") == 0)){
            string inp_outp = buffer;      //On r�cup�re la cha�ne de caract�re INPUT ou OUTPUT
            infile >> buffer;              //On r�cup�re soit une entr�e ou une sortie en fonction de la ligne
            while(buffer.compare(";") != 0){
                if(inp_outp.compare("OUTPUT") == 0) index_outp++;    //comptes le nombre de sorties primaires
                inputs_outputs.push_back(buffer);       //Ajout des entr�es et sorties primaires
                infile >> buffer;
           }
        }
        //On se place dans le cas des portes
        else if(buffer.compare(";") != 0 ){
            int cpt_inp = 0;            //comptes le nb d'entr�es
            string type_g = buffer;     //type de porte
            infile >> buffer;           //le nom de la porte
            ID_node.push_back(buffer);  //mets les noms des portes dans le ID_node
            infile >> buffer;           //la sortie
            infile >> buffer;           //premi�re entr�e

            //On compte le nombre d'entr�es de la porte
            while(buffer.compare(";") != 0){
                cpt_inp ++;
                infile >> buffer;
            }

            //On cr�e la porte selon le type de celle-ci et le nombre d'entr�e
            if( type_g.compare("and") == 0)
            {
                list_gates.push_back(new AND(cpt_inp));
            }
            if( type_g.compare("nand") == 0)
            {
                list_gates.push_back(new NAND(cpt_inp));
            }
            if( type_g.compare("or") == 0)
            {
                list_gates.push_back(new OR(cpt_inp));
            }
            if( type_g.compare("nor") == 0)
            {
                list_gates.push_back(new NOR(cpt_inp));
            }
            if( type_g.compare("not") == 0)
            {
                list_gates.push_back(new NOT(cpt_inp));
            }
            if( type_g.compare("xor") == 0)
            {
                list_gates.push_back(new XOR(cpt_inp));
            }
        }
    }

    index_inp = ID_node.size();    //Mise � jour de l'indice des entr�es primaires

    //Ajout du vecteur d'entr�es et de sorties primaires � la table ID_node
    for( int i = 0; i < inputs_outputs.size(); i++){
            ID_node.push_back(inputs_outputs[i]);
    }

    infile.close();     //Fermeture du fichier

    index_outp = ID_node.size() - index_outp;   //Mise � jour de l'indice des sorties primaires

}

vector<string> graph::getID_node()
{
    return ID_node;
}

vector<PorteGenerique*> graph::getList_gates()
{
    return list_gates;
}

void graph::AdjacencyMatrix(string desc_cir)
{

    fstream infile(desc_cir);
    string line;
    string buffer;

    map<string, int> outputs_inter;     //Variable contenant toutes les sorties
                                        //dont la cl� est le nom de la node, et la valeur est l'index de la node

    int index_gate = 0;     //Variable repr�sentant la porte actuel
    int index_connec;       //Variable repr�sentant une node connect�e � la node actuel

    getline(infile, line); getline(infile, line);       //sauts des lignes INPUTS et OUTPUTS
    infile >> buffer;       //type de la premi�re porte

    //On parcours le fichier tant que l'on n'a pas atteint la fin du fichier
    while(!infile.eof()){
        infile >> buffer;       //nom de la porte
        infile >> buffer;       //sortie de la porte

        //ajout de la sortie inter si ce n
        outputs_inter.insert({buffer, index_gate});

        infile >> buffer;   //premi�re entr�e de la porte

        //Variable contenant toutes les nodes, pr�c�dentes, connect�es � la porte actuele
        vector<int> nodes_connec(ID_node.size());


        while(buffer.compare(";") != 0){
            //On recherche la valeur du buffer est une entr�e primaire qui est compris
            //entre les index des entr�es et sorties
            index_connec = findIndex(ID_node, buffer, index_inp, index_outp);
            //Si la valeur est trouv�e alors on l'a place au bon indice
            //Sinon c'est une sortie interm�diaire donc une porte
            if( index_connec != -1) nodes_connec[index_connec] = 1;
            else{
                index_connec = outputs_inter.at(buffer);
                nodes_connec[index_connec] = 1;
            }
            infile >> buffer;
        }

        infile >> buffer;   //type de la porte
        adjMatrix.push_back(nodes_connec);      //Ajout du vecteur de nodes � la matrice d'adjacence
        index_gate++;
    }
    //Remplissaqe de la matrice d'adjacence par des vecteurs vides car aucunes entr�es primaires
    //ne poss�dent de nodes connect�es pr�c�demment � elles
    vector<int> vide(ID_node.size());
    for(int i = 0; i<(index_outp - index_inp); i++) adjMatrix.push_back(vide);


    string name_gate;

    //On ajoute les sorties primaires � la matrice d'adjacence
    for(int i = index_outp; i < ID_node.size(); i++){
        vector<int> nodes_connec(ID_node.size());
        name_gate = ID_node[i];                 //on r�cup�re de la sortie primaire
        nodes_connec[outputs_inter.at(name_gate)] = 1;
        adjMatrix.push_back(nodes_connec);
    }
    infile.close();
}
vector<vector<int>> graph::getAdjMatrix(){
        return adjMatrix;
}


void graph::solve(string file_vec){

    ifstream infile(file_vec);
    string line;       //Variable contenant une ligne du fichier file_vec

    getline(infile, line);      //nombre de vecteurs d'entr�es
    int iter = stoi(line);      //on stocke la valeur r�cup�r� sous le type int
    vector<int> outputs(ID_node.size() - index_outp);   //vecteurs de sorties primaire

    cout << "start simulation of " << iter<< " vectors" << endl;

    //On effectue le parcours des noeuds du circuits pour chaque vecteur d'entr�es
    for(int i = 0; i<iter ; i++){
        getline(infile, line);      //On recup�re un vecteur d'entr�es
        //On parcourt chaque valeur du vecteur
        for(int j = 0; j<line.size(); j++){
            char val = line[j];
            DFS(j+index_inp, atoi(&val), -1);
        }

        //On recherche les valeurs des sorties
        cout << "Vector " << i << " : " << line << "\t-> ";
        for(int j = 0; j<outputs.size(); j++){
            //On r�cup�re l'index de la porte correspondant � la sortie primaire
            int index_gate = findIndex(adjMatrix[j+index_outp], 1, 0, list_gates.size());
            outputs[j] = (*list_gates[index_gate]).Calculate_output();
            cout << outputs[j];
        }
        cout << endl;
    }
    cout << endl;
    infile.close();
}


void graph::DFS(int noeud, int val_prec, int noeud_prec){

    vector<int> nextNoeuds;     //vecteurs contenant les prochains noeuds par rapport au noeud actuel

    //Ajout des noeuds suivants
    for(int i = 0; i < ID_node.size(); i++){
        if(adjMatrix[i][noeud] == 1) nextNoeuds.push_back(i);
    }

    //S'il n'y aucun noeuds suivants alors on est sur une sortie primaire
    if(!nextNoeuds.empty()){
        //On parcours les noeuds suivants
        for(int i = 0; i < nextNoeuds.size(); i++){
            //Selon la table d'ID_nodes toutes les portes sont comprises entre 0 et l'index_inp
            if(noeud < index_inp){

                //On recherche la position de la valeur pr�c�dente que l'on place dans la bonne entr�e de la porte
                int index_input = -1;
                for(int j = 0; j<=noeud_prec; j++){
                    index_input += adjMatrix[noeud][j];
                }

                //On met � jour l'entr�e de la correspondante au noeud actuel
                (*list_gates[noeud]).Set_input(index_input, val_prec);
                //On calcul la nouvelle sortie de la porte et on explore le noeud suivant et le noeud actuel devient le pr�c�dent
                int out = (*list_gates[noeud]).Calculate_output();
                DFS(nextNoeuds[i], out, noeud);
            }
            //On est forc�ment dans une entr�e primaire donc explore le noeud suivant
            else DFS(nextNoeuds[i], val_prec, noeud);
        }
    }
}

graph::~graph()
{

}
